#!/usr/bin/env python3
"""
NSX-T PARALLEL Backup System
Runs backups for all NSX environments in parallel using separate processes
This is the main orchestrator that your web UI calls
"""

import os
import sys
import json
import datetime
import time
import subprocess
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.append(parent_dir)

from modules.utils.extensive_logger import extensive_log


class ParallelNSXBackup:
    """Parallel NSX backup manager using separate processes"""
    
    def __init__(self):
        # Load environments from configuration
        self.environments = self._load_nsx_environments()
        
        # Setup backup directory
        self.backup_base_dir = Path(__file__).parent
        self.backup_dir = self.backup_base_dir / "nsx_backups"
        
        # Clean backup directory contents (but don't remove the directory itself if it's a mount)
        if self.backup_dir.exists():
            # Clean contents only, don't remove the directory (it might be a mount point)
            for item in self.backup_dir.iterdir():
                if item.is_file():
                    item.unlink()
                elif item.is_dir():
                    shutil.rmtree(item)
        else:
            # Create directory if it doesn't exist
            self.backup_dir.mkdir(exist_ok=True)
        
        extensive_log.info("parallel_backup", f"Parallel backup system initialized for {len(self.environments)} environments")
    
    def _load_nsx_environments(self):
        """Load NSX environments from configuration"""
        try:
            config_file = Path(__file__).parent.parent / "nsx_environments.json"
            
            with open(config_file, 'r') as f:
                config_data = json.load(f)
            
            environments = []
            for env in config_data.get('environments', []):
                if env.get('status') == 'configured':
                    environments.append({
                        'name': env['name'],
                        'ip': env['ip'],
                        'environment': env['environment'].upper()
                    })
            
            return environments
            
        except Exception as e:
            # Fallback to defaults
            return [
                {"name": "NSX-T UK", "ip": "10.190.200.3", "environment": "UK"},
                {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US"},
                {"name": "NSX-T EU", "ip": "10.55.0.3", "environment": "EU"},
                {"name": "NSX-T IN", "ip": "10.23.0.3", "environment": "IN"}
            ]
    
    def run_backup_process(self, env_config):
        """Run backup for a single environment in a separate process"""
        env_code = env_config['environment'].lower()
        script_path = self.backup_base_dir / "backup_workers" / f"backup_{env_code}.py"
        
        # Check if individual script exists
        if not script_path.exists():
            print(f"⚠️  Script not found for {env_config['name']}: {script_path}")
            return {
                'environment': env_config['name'],
                'environment_code': env_config['environment'],
                'success': False,
                'error': f"Script not found: {script_path}"
            }
        
        try:
            print(f"🚀 Starting parallel backup for {env_config['name']}...")
            
            # Run the backup script as a subprocess
            result = subprocess.run(
                [sys.executable, str(script_path)],
                capture_output=True,
                text=True,
                timeout=300  # 5 minute timeout per environment (IN has 3x higher latency)
            )
            
            # Check if backup was successful by checking if the backup file exists
            backup_file = self.backup_dir / f"{env_config['environment']}_complete_backup.json"
            if backup_file.exists():
                # Get file size for summary
                file_size = backup_file.stat().st_size
                return {
                    'environment': env_config['name'],
                    'environment_code': env_config['environment'],
                    'success': True,
                    'file': backup_file.name,
                    'file_size': file_size
                }
            else:
                return {
                    'environment': env_config['name'],
                    'environment_code': env_config['environment'],
                    'success': False,
                    'error': result.stderr if result.stderr else "Backup file not created"
                }
                
        except subprocess.TimeoutExpired:
            return {
                'environment': env_config['name'],
                'environment_code': env_config['environment'],
                'success': False,
                'error': "Backup timed out after 3 minutes"
            }
        except Exception as e:
            return {
                'environment': env_config['name'],
                'environment_code': env_config['environment'],
                'success': False,
                'error': str(e)
            }
    
    def print_summary(self, summaries, total_time):
        """Print summary to console only"""
        successful = [s for s in summaries if s.get('success', False)]
        failed = [s for s in summaries if not s.get('success', False)]
        
        print("\n" + "=" * 80)
        print("✅ PARALLEL BACKUP COMPLETED!")
        print("=" * 80)
        print(f"📊 Results:")
        print(f"   • Total Time: {total_time}s")
        print(f"   • Environments Backed Up: {len(successful)}/{len(self.environments)}")
        
        if successful:
            print(f"\n✅ Successfully backed up:")
            for s in successful:
                print(f"   • {s['environment']}: {s.get('file', 'N/A')}")
        
        if failed:
            print(f"\n❌ Failed backups:")
            for s in failed:
                print(f"   • {s['environment']}: {s.get('error', 'Unknown error')}")
    
    
    def run_complete_backup(self):
        """Run parallel backup of all environments"""
        overall_start = time.time()
        
        print("\n" + "=" * 80)
        print("🚀 NSX-T PARALLEL BACKUP SYSTEM")
        print("=" * 80)
        print(f"⚡ Running {len(self.environments)} backups in PARALLEL")
        print(f"⚡ Each environment runs in its own process")
        print("=" * 80)
        
        summaries = []
        
        # Run all backups in parallel using ThreadPoolExecutor (lighter than processes)
        with ThreadPoolExecutor(max_workers=len(self.environments)) as executor:
            # Submit all backup jobs
            future_to_env = {
                executor.submit(self.run_backup_process, env): env 
                for env in self.environments
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_env):
                env = future_to_env[future]
                try:
                    result = future.result()
                    summaries.append(result)
                    
                    if result.get('success'):
                        print(f"✅ {result['environment']}: Backup created successfully")
                    else:
                        print(f"❌ {result['environment']}: Failed - {result.get('error', 'Unknown error')}")
                        
                except Exception as e:
                    print(f"❌ {env['name']}: Exception - {e}")
                    summaries.append({
                        'environment': env['name'],
                        'environment_code': env['environment'],
                        'success': False,
                        'error': str(e)
                    })
        
        # Print summary
        overall_time = round(time.time() - overall_start, 2)
        self.print_summary(summaries, overall_time)
        
        successful = [s for s in summaries if s.get('success', False)]
        
        return len(successful) > 0


def main():
    """Main function"""
    try:
        backup = ParallelNSXBackup()
        success = backup.run_complete_backup()
        
        if success:
            print("\n🎯 All NSX environments backed up in PARALLEL!")
            print("⚡ Maximum speed achieved through parallel processing!")
            return True
        else:
            print("\n⚠️  Some backups failed. Check the logs for details.")
            return False
            
    except KeyboardInterrupt:
        print("\n❌ Backup cancelled by user")
        return False
    except Exception as e:
        print(f"\n❌ Backup failed: {e}")
        extensive_log.error("parallel_backup", f"Critical failure: {e}")
        return False


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
