#!/usr/bin/env python3
"""Worker script for backing up a single NSX environment"""

import os
import sys
import json
import datetime
import time
from pathlib import Path

# Add necessary directories to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)  # policies backup dir
grandparent_dir = os.path.dirname(parent_dir)  # data dir
great_grandparent_dir = os.path.dirname(grandparent_dir)  # create_DC_rules dir
sys.path.append(great_grandparent_dir)  # For modules import

from modules import NSX_login
from modules.NSX_login import get_nsx_display_name
from modules.create_service_API import get_authenticated_session
from modules.search_policy import get_policy_rules
from modules.utils.extensive_logger import extensive_log

import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def backup_single_environment(env_config):
    """Backup a single NSX environment"""
    start_time = time.time()
    
    try:
        print(f"[{env_config['environment']}] Starting backup for {env_config['name']}...")
        extensive_log.info("backup_worker", f"Starting backup for {env_config['name']}")
        
        # Environment is already set via os.environ in the calling script
        # Refresh the NSX_login module to use the correct environment
        NSX_login.refresh_config()
        
        # Get authenticated session
        session = get_authenticated_session(require_policy_access=False)
        if not session:
            raise Exception(f"Failed to authenticate to {env_config['name']}")
        
        print(f"[{env_config['environment']}] Authenticated successfully")
        
        # Build base URL
        base_url = f"https://{env_config['ip']}"
        
        # Get all policies
        domain_id = "default"
        policies_url = f"{base_url}/policy/api/v1/infra/domains/{domain_id}/security-policies"
        
        response = session.get(policies_url, verify=False, timeout=30)
        if response.status_code != 200:
            raise Exception(f"Failed to get policies: HTTP {response.status_code}")
        
        policies_data = response.json()
        policies = policies_data.get('results', [])
        
        print(f"[{env_config['environment']}] Found {len(policies)} policies")
        
        # Get rules for each policy
        policies_with_rules = []
        total_rules = 0
        
        for i, policy in enumerate(policies, 1):
            if i % 10 == 0:
                print(f"[{env_config['environment']}] Processing policy {i}/{len(policies)}...")
            
            rules = get_policy_rules(session, policy)
            
            enhanced_policy = dict(policy)
            enhanced_policy['rules'] = rules if rules else []
            enhanced_policy['rule_count'] = len(rules) if rules else 0
            total_rules += enhanced_policy['rule_count']
            
            # Add rule metadata
            if rules:
                enhanced_policy['rule_metadata'] = []
                for rule in rules:
                    rule_meta = {
                        'sources_excluded': rule.get('sources_excluded', False),
                        'destinations_excluded': rule.get('destinations_excluded', False),
                        'disabled': rule.get('disabled', False),
                        'action': rule.get('action'),
                        'sequence_number': rule.get('sequence_number')
                    }
                    enhanced_policy['rule_metadata'].append(rule_meta)
            
            policies_with_rules.append(enhanced_policy)
        
        print(f"[{env_config['environment']}] Found {total_rules} total rules")
        
        # Collect unique groups and services
        all_unique_groups = set()
        all_unique_services = set()
        
        for policy in policies_with_rules:
            for rule in policy.get('rules', []):
                # Extract groups
                for group_path in rule.get('source_groups', []) + rule.get('destination_groups', []):
                    if isinstance(group_path, str) and group_path.startswith('/'):
                        all_unique_groups.add(group_path.split('/')[-1])
                
                # Extract services
                for service in rule.get('services', []):
                    if isinstance(service, str):
                        if service == "ANY":
                            all_unique_services.add("ANY")
                        elif service.startswith('/'):
                            all_unique_services.add(service.split('/')[-1])
                        else:
                            all_unique_services.add(service)
        
        print(f"[{env_config['environment']}] Found {len(all_unique_groups)} unique groups, {len(all_unique_services)} unique services")
        
        # Get all groups
        groups_url = f"{base_url}/policy/api/v1/infra/domains/{domain_id}/groups"
        response = session.get(groups_url, verify=False, timeout=30)
        
        if response.status_code == 200:
            groups_data = response.json()
            groups = groups_data.get('results', [])
            
            user_groups = []
            system_groups = []
            
            for group in groups:
                if group.get('_system_owned', False):
                    system_groups.append(group)
                else:
                    user_groups.append(group)
            
            all_groups = {
                'all_groups': groups,
                'user_groups': user_groups,
                'system_groups': system_groups
            }
        else:
            all_groups = {'all_groups': [], 'user_groups': [], 'system_groups': []}
        
        # Get all services
        services_url = f"{base_url}/policy/api/v1/infra/services"
        response = session.get(services_url, verify=False, timeout=30)
        
        if response.status_code == 200:
            services_data = response.json()
            services = services_data.get('results', [])
            
            user_services = []
            system_services = []
            default_services = []
            
            for service in services:
                if service.get('_system_owned', False):
                    system_services.append(service)
                elif service.get('is_default', False):
                    default_services.append(service)
                else:
                    user_services.append(service)
            
            all_services = {
                'all_services': services,
                'user_services': user_services,
                'default_services': default_services,
                'system_services': system_services
            }
        else:
            all_services = {'all_services': [], 'user_services': [], 'default_services': [], 'system_services': []}
        
        # Create backup data
        backup_data = {
            'environment': {
                'name': env_config['name'],
                'ip': env_config['ip'],
                'environment_code': env_config['environment'],
                'base_url': base_url,
                'display_name': get_nsx_display_name()
            },
            'backup_timestamp': datetime.datetime.now().isoformat(),
            'statistics': {
                'total_policies': len(policies_with_rules),
                'total_rules': total_rules,
                'total_unique_groups_analyzed': len(all_unique_groups),
                'total_unique_services_analyzed': len(all_unique_services),
                'total_groups': len(all_groups.get('all_groups', [])),
                'total_services': len(all_services.get('all_services', [])),
                'user_groups': len(all_groups.get('user_groups', [])),
                'user_services': len(all_services.get('user_services', [])),
                'backup_time_seconds': round(time.time() - start_time, 2)
            },
            'policies': policies_with_rules,
            'groups': all_groups,
            'services': all_services,
            'analyzed_resources': {
                'groups_analysis': {},  # Skipped for speed
                'services_analysis': {}  # Skipped for speed
            }
        }
        
        # Save to JSON file
        backup_dir = Path(__file__).parent.parent / "nsx_backups"
        backup_dir.mkdir(exist_ok=True)
        
        backup_file = backup_dir / f"{env_config['environment']}_complete_backup.json"
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(backup_data, f, indent=2, ensure_ascii=False)
        
        elapsed = round(time.time() - start_time, 2)
        print(f"[{env_config['environment']}] ✅ Backup completed in {elapsed}s - {backup_file.name}")
        return True
        
    except Exception as e:
        print(f"[{env_config['environment']}] ❌ Backup failed: {e}")
        extensive_log.error("backup_worker", f"Error backing up {env_config['name']}: {e}")
        return False


if __name__ == "__main__":
    # This can be called directly for testing
    import sys
    if len(sys.argv) > 1:
        env = sys.argv[1].upper()
        configs = {
            'UK': {"name": "NSX-T UK", "ip": "10.190.200.3", "environment": "UK"},
            'US': {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US"},
            'EU': {"name": "NSX-T EU", "ip": "10.55.0.3", "environment": "EU"},
            'IN': {"name": "NSX-T IN", "ip": "10.23.0.3", "environment": "IN"}
        }
        if env in configs:
            os.environ['NSX_IP'] = configs[env]['ip']
            os.environ['NSX_ENV'] = env
            backup_single_environment(configs[env])
        else:
            print(f"Unknown environment: {env}")
    else:
        print("Usage: python3 create_backup_worker.py [UK|US|EU|IN]")
