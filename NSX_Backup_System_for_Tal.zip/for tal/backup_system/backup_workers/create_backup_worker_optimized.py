#!/usr/bin/env python3
"""Optimized worker script for backing up a single NSX environment using async/concurrent requests"""

import os
import sys
import json
import datetime
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

# CRITICAL: Force unbuffered output for container visibility
sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', buffering=1)
sys.stderr = os.fdopen(sys.stderr.fileno(), 'w', buffering=1)

# Add necessary directories to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)  # policies backup dir
grandparent_dir = os.path.dirname(parent_dir)  # data dir
great_grandparent_dir = os.path.dirname(grandparent_dir)  # create_DC_rules dir
sys.path.append(great_grandparent_dir)  # For modules import

from modules import NSX_login
from modules.NSX_login import get_nsx_display_name
from modules.create_service_API import get_authenticated_session
from modules.utils.extensive_logger import extensive_log

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class OptimizedNSXBackup:
    def __init__(self, env_config):
        self.env_config = env_config
        self.session = None
        self.base_url = f"https://{env_config['ip']}"
        self.domain_id = "default"
    
    def get_policy_rules_silent(self, policy_data):
        """Silent version of get_policy_rules without print statements"""
        try:
            policy_id = policy_data.get('id')
            if not policy_id:
                return []
            
            # Get rules for this policy
            rules_url = f"{self.base_url}/policy/api/v1/infra/domains/default/security-policies/{policy_id}/rules"
            response = self.session.get(rules_url, verify=False, timeout=30)
            
            if response.status_code == 200:
                rules_data = response.json()
                return rules_data.get("results", [])
            else:
                return []
        except Exception:
            return []
        
    def authenticate(self):
        """Get authenticated session with connection pooling"""
        print(f"[{self.env_config['environment']}] Authenticating to NSX at {self.base_url}...", flush=True)
        print(f"[{self.env_config['environment']}] Environment variables: NSX_IP={os.environ.get('NSX_IP')}, NSX_ENV={os.environ.get('NSX_ENV')}", flush=True)
        
        NSX_login.refresh_config()
        print(f"[{self.env_config['environment']}] After refresh_config: NSX_IP={NSX_login.NSX_IP}, NSX_ENV={NSX_login.NSX_ENV}", flush=True)
        
        try:
            self.session = get_authenticated_session(require_policy_access=False)
        except Exception as e:
            print(f"[{self.env_config['environment']}] FATAL: get_authenticated_session failed: {e}", flush=True)
            raise Exception(f"Failed to get authenticated session for {self.env_config['name']}: {e}")
        
        if not self.session:
            raise Exception(f"Failed to authenticate to {self.env_config['name']} - session is None")
        
        # Add connection pooling and retry strategy
        adapter = HTTPAdapter(
            pool_connections=20,
            pool_maxsize=20,
            max_retries=Retry(total=2, backoff_factor=0.1)
        )
        self.session.mount('https://', adapter)
        self.session.mount('http://', adapter)
        
        print(f"[{self.env_config['environment']}] Authentication successful", flush=True)
        
    def fetch_policies(self):
        """Fetch all policies"""
        policies_url = f"{self.base_url}/policy/api/v1/infra/domains/{self.domain_id}/security-policies"
        response = self.session.get(policies_url, verify=False, timeout=30)
        if response.status_code != 200:
            raise Exception(f"Failed to get policies: HTTP {response.status_code}")
        return response.json().get('results', [])
    
    def fetch_rules_batch(self, policies):
        """Fetch rules for multiple policies concurrently using ThreadPoolExecutor"""
        policies_with_rules = []
        total_rules = 0
        
        def fetch_single_policy_rules(policy_data):
            """Helper to fetch rules for a single policy"""
            policy, idx, total = policy_data
            if idx % 20 == 0:  # Reduce logging frequency
                print(f"[{self.env_config['environment']}] Processing policy {idx}/{total}...")
            
            rules = self.get_policy_rules_silent(policy)
            
            enhanced_policy = dict(policy)
            enhanced_policy['rules'] = rules if rules else []
            enhanced_policy['rule_count'] = len(rules) if rules else 0
            
            # Add rule metadata
            if rules:
                enhanced_policy['rule_metadata'] = []
                for rule in rules:
                    rule_meta = {
                        'sources_excluded': rule.get('sources_excluded', False),
                        'destinations_excluded': rule.get('destinations_excluded', False),
                        'disabled': rule.get('disabled', False),
                        'action': rule.get('action'),
                        'sequence_number': rule.get('sequence_number')
                    }
                    enhanced_policy['rule_metadata'].append(rule_meta)
            
            return enhanced_policy
        
        # Process policies in batches using ThreadPoolExecutor with more workers
        with ThreadPoolExecutor(max_workers=20) as executor:
            policy_data = [(p, i, len(policies)) for i, p in enumerate(policies, 1)]
            results = list(executor.map(fetch_single_policy_rules, policy_data))
        
        for result in results:
            total_rules += result['rule_count']
            policies_with_rules.append(result)
        
        print(f"[{self.env_config['environment']}] Found {total_rules} total rules")
        return policies_with_rules, total_rules
    
    def fetch_groups_and_services_parallel(self):
        """Fetch groups and services in parallel"""
        all_groups = {'all_groups': [], 'user_groups': [], 'system_groups': []}
        all_services = {'all_services': [], 'user_services': [], 'default_services': [], 'system_services': []}
        
        def fetch_groups():
            try:
                groups_url = f"{self.base_url}/policy/api/v1/infra/domains/{self.domain_id}/groups"
                print(f"[{self.env_config['environment']}] Fetching groups from: {groups_url}", flush=True)
                
                # Retry logic for rate limiting (HTTP 429)
                max_retries = 3
                for attempt in range(max_retries):
                    response = self.session.get(groups_url, verify=False, timeout=30)
                    print(f"[{self.env_config['environment']}] Groups API status code: {response.status_code}", flush=True)
                    
                    if response.status_code == 200:
                        groups_data = response.json()
                        groups = groups_data.get('results', [])
                        print(f"[{self.env_config['environment']}] Found {len(groups)} groups from API", flush=True)
                        
                        user_groups = []
                        system_groups = []
                        
                        for group in groups:
                            if group.get('_system_owned', False):
                                system_groups.append(group)
                            else:
                                user_groups.append(group)
                        
                        return {
                            'all_groups': groups,
                            'user_groups': user_groups,
                            'system_groups': system_groups
                        }
                    elif response.status_code == 429:
                        if attempt < max_retries - 1:
                            wait_time = (attempt + 1) * 2  # 2s, 4s, 6s
                            print(f"[{self.env_config['environment']}] Rate limited (429), retrying in {wait_time}s...")
                            time.sleep(wait_time)
                            continue
                        else:
                            print(f"[{self.env_config['environment']}] Groups API rate limited after {max_retries} retries", flush=True)
                            return {'all_groups': [], 'user_groups': [], 'system_groups': []}
                    else:
                        print(f"[{self.env_config['environment']}] Groups API returned status {response.status_code}", flush=True)
                        print(f"[{self.env_config['environment']}] Response text: {response.text[:500]}", flush=True)
                        return {'all_groups': [], 'user_groups': [], 'system_groups': []}
                        
            except Exception as e:
                print(f"[{self.env_config['environment']}] ERROR fetching groups: {e}", flush=True)
                import traceback
                traceback.print_exc()
                return {'all_groups': [], 'user_groups': [], 'system_groups': []}
        
        def fetch_services():
            try:
                services_url = f"{self.base_url}/policy/api/v1/infra/services"
                print(f"[{self.env_config['environment']}] Fetching services from: {services_url}", flush=True)
                
                # Retry logic for rate limiting (HTTP 429)
                max_retries = 3
                for attempt in range(max_retries):
                    response = self.session.get(services_url, verify=False, timeout=30)
                    print(f"[{self.env_config['environment']}] Services API status code: {response.status_code}", flush=True)
                    
                    if response.status_code == 200:
                        services_data = response.json()
                        services = services_data.get('results', [])
                        print(f"[{self.env_config['environment']}] Found {len(services)} services from API", flush=True)
                        
                        user_services = []
                        system_services = []
                        default_services = []
                        
                        for service in services:
                            if service.get('_system_owned', False):
                                system_services.append(service)
                            elif service.get('is_default', False):
                                default_services.append(service)
                            else:
                                user_services.append(service)
                        
                        return {
                            'all_services': services,
                            'user_services': user_services,
                            'default_services': default_services,
                            'system_services': system_services
                        }
                    elif response.status_code == 429:
                        if attempt < max_retries - 1:
                            wait_time = (attempt + 1) * 2  # 2s, 4s, 6s
                            print(f"[{self.env_config['environment']}] Rate limited (429), retrying in {wait_time}s...")
                            time.sleep(wait_time)
                            continue
                        else:
                            print(f"[{self.env_config['environment']}] Services API rate limited after {max_retries} retries", flush=True)
                            return {'all_services': [], 'user_services': [], 'default_services': [], 'system_services': []}
                    else:
                        print(f"[{self.env_config['environment']}] Services API returned status {response.status_code}", flush=True)
                        print(f"[{self.env_config['environment']}] Response text: {response.text[:500]}", flush=True)
                        return {'all_services': [], 'user_services': [], 'default_services': [], 'system_services': []}
                        
            except Exception as e:
                print(f"[{self.env_config['environment']}] ERROR fetching services: {e}", flush=True)
                import traceback
                traceback.print_exc()
                return {'all_services': [], 'user_services': [], 'default_services': [], 'system_services': []}
        
        # Fetch groups and services in parallel
        with ThreadPoolExecutor(max_workers=2) as executor:
            future_groups = executor.submit(fetch_groups)
            future_services = executor.submit(fetch_services)
            
            all_groups = future_groups.result()
            all_services = future_services.result()
        
        return all_groups, all_services
    
    def extract_unique_resources(self, policies_with_rules):
        """Extract unique groups and services from policies"""
        all_unique_groups = set()
        all_unique_services = set()
        
        for policy in policies_with_rules:
            for rule in policy.get('rules', []):
                # Extract groups
                for group_path in rule.get('source_groups', []) + rule.get('destination_groups', []):
                    if isinstance(group_path, str) and group_path.startswith('/'):
                        all_unique_groups.add(group_path.split('/')[-1])
                
                # Extract services
                for service in rule.get('services', []):
                    if isinstance(service, str):
                        if service == "ANY":
                            all_unique_services.add("ANY")
                        elif service.startswith('/'):
                            all_unique_services.add(service.split('/')[-1])
                        else:
                            all_unique_services.add(service)
        
        return all_unique_groups, all_unique_services
    
    def run_backup(self):
        """Run the optimized backup process"""
        start_time = time.time()
        
        try:
            print(f"[{self.env_config['environment']}] Starting optimized backup for {self.env_config['name']}...")
            extensive_log.info("backup_worker_optimized", f"Starting backup for {self.env_config['name']}")
            
            # Authenticate
            self.authenticate()
            
            # Fetch policies
            policies = self.fetch_policies()
            print(f"[{self.env_config['environment']}] Found {len(policies)} policies")
            
            # Fetch rules for all policies concurrently
            policies_with_rules, total_rules = self.fetch_rules_batch(policies)
            
            # Extract unique resources
            all_unique_groups, all_unique_services = self.extract_unique_resources(policies_with_rules)
            print(f"[{self.env_config['environment']}] Found {len(all_unique_groups)} unique groups, {len(all_unique_services)} unique services")
            
            # Add delay to avoid rate limiting after heavy rule fetching
            print(f"[{self.env_config['environment']}] Waiting 3s before fetching groups/services to avoid rate limiting...")
            time.sleep(3)
            
            # Fetch groups and services in parallel
            all_groups, all_services = self.fetch_groups_and_services_parallel()
            
            # CRITICAL: Validate that we actually got groups/services before saving
            groups_count = len(all_groups.get('all_groups', []))
            services_count = len(all_services.get('all_services', []))
            
            print(f"[{self.env_config['environment']}] Fetched {groups_count} groups, {services_count} services", flush=True)
            
            if groups_count == 0 and services_count == 0:
                raise Exception(f"FATAL: Backup would contain 0 groups and 0 services - aborting to prevent data loss! This is likely an NSX authentication or session issue.")
            
            if groups_count == 0:
                print(f"[{self.env_config['environment']}] WARNING: 0 groups fetched - this may indicate an API issue", flush=True)
            
            if services_count == 0:
                print(f"[{self.env_config['environment']}] WARNING: 0 services fetched - this may indicate an API issue", flush=True)
            
            # Create backup data
            backup_data = {
                'environment': {
                    'name': self.env_config['name'],
                    'ip': self.env_config['ip'],
                    'environment_code': self.env_config['environment'],
                    'base_url': self.base_url,
                    'display_name': get_nsx_display_name()
                },
                'backup_timestamp': datetime.datetime.now().isoformat(),
                'statistics': {
                    'total_policies': len(policies_with_rules),
                    'total_rules': total_rules,
                    'total_unique_groups_analyzed': len(all_unique_groups),
                    'total_unique_services_analyzed': len(all_unique_services),
                    'total_groups': len(all_groups.get('all_groups', [])),
                    'total_services': len(all_services.get('all_services', [])),
                    'user_groups': len(all_groups.get('user_groups', [])),
                    'user_services': len(all_services.get('user_services', [])),
                    'backup_time_seconds': round(time.time() - start_time, 2)
                },
                'policies': policies_with_rules,
                'groups': all_groups,
                'services': all_services,
                'analyzed_resources': {
                    'groups_analysis': {},  # Skipped for speed
                    'services_analysis': {}  # Skipped for speed
                }
            }
            
            # Save to JSON file (use orjson if available for faster serialization)
            backup_dir = Path(__file__).parent.parent / "nsx_backups"
            backup_dir.mkdir(exist_ok=True)
            
            backup_file = backup_dir / f"{self.env_config['environment']}_complete_backup.json"
            
            # Write JSON efficiently
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(backup_data, f, indent=2, ensure_ascii=False)
            
            elapsed = round(time.time() - start_time, 2)
            print(f"[{self.env_config['environment']}] ✅ Optimized backup completed in {elapsed}s - {backup_file.name}")
            return True
            
        except Exception as e:
            print(f"[{self.env_config['environment']}] ❌ Backup failed: {e}")
            extensive_log.error("backup_worker_optimized", f"Error backing up {self.env_config['name']}: {e}")
            return False


def backup_single_environment(env_config):
    """Wrapper function to maintain compatibility"""
    backup = OptimizedNSXBackup(env_config)
    return backup.run_backup()


if __name__ == "__main__":
    # This can be called directly for testing
    import sys
    if len(sys.argv) > 1:
        env = sys.argv[1].upper()
        configs = {
            'UK': {"name": "NSX-T UK", "ip": "10.190.200.3", "environment": "UK"},
            'US': {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US"},
            'EU': {"name": "NSX-T EU", "ip": "10.55.0.3", "environment": "EU"},
            'IN': {"name": "NSX-T IN", "ip": "10.23.0.3", "environment": "IN"}
        }
        if env in configs:
            os.environ['NSX_IP'] = configs[env]['ip']
            os.environ['NSX_ENV'] = env
            backup_single_environment(configs[env])
        else:
            print(f"Unknown environment: {env}")
    else:
        print("Usage: python3 create_backup_worker_optimized.py [UK|US|EU|IN]")
