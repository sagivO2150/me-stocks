#!/usr/bin/env python3
"""NSX-T US Environment Backup"""
import os
import sys
os.environ['NSX_IP'] = '10.148.0.3'
os.environ['NSX_ENV'] = 'US'

# Add current and parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
project_root = os.path.dirname(os.path.dirname(parent_dir))  # Go up to project root
sys.path.insert(0, current_dir)  # Add current dir for create_backup_worker
sys.path.append(parent_dir)  # Add parent for other modules
sys.path.append(project_root)  # Add project root for modules

from create_backup_worker_optimized import backup_single_environment

if __name__ == "__main__":
    env_config = {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US"}
    backup_single_environment(env_config)
