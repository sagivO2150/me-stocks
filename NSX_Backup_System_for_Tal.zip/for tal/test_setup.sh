#!/bin/bash
# Quick test script to verify the backup system is working

echo "=================================="
echo "NSX Backup System - Quick Test"
echo "=================================="
echo ""

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed or not in PATH"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"
echo ""

# Check if required modules exist
echo "Checking required files..."
if [ ! -f "modules/NSX_login.py" ]; then
    echo "❌ modules/NSX_login.py not found"
    exit 1
fi
echo "✅ NSX_login.py found"

if [ ! -f "backup_system/create_backup.py" ]; then
    echo "❌ backup_system/create_backup.py not found"
    exit 1
fi
echo "✅ create_backup.py found"

if [ ! -f "config/nsx_environments.json" ]; then
    echo "❌ config/nsx_environments.json not found"
    exit 1
fi
echo "✅ nsx_environments.json found"

echo ""
echo "Checking Python dependencies..."
python3 -c "import requests" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ 'requests' module not installed"
    echo "   Run: pip install -r requirements.txt"
    exit 1
fi
echo "✅ requests module installed"

python3 -c "import urllib3" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "❌ 'urllib3' module not installed"
    echo "   Run: pip install -r requirements.txt"
    exit 1
fi
echo "✅ urllib3 module installed"

echo ""
echo "=================================="
echo "✅ All checks passed!"
echo "=================================="
echo ""
echo "Ready to run backup. Execute:"
echo "  cd backup_system"
echo "  python3 create_backup.py"
echo ""
echo "Or set your username first:"
echo "  export NSX_USERNAME='your_username'"
echo "  cd backup_system && python3 create_backup.py"
