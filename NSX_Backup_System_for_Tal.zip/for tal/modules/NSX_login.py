#!/usr/bin/env python3
"""
Dynamic NSX-T login script
Logs into NSX-T and establishes a session for further API calls
Supports multiple NSX environments with separate token caching
Reads environment configurations dynamically from nsx_environments.json
"""

import requests
import urllib3
import getpass
import sys
import os
import json
from pathlib import Path

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# === Configuration ===
# Username is now ALWAYS retrieved from session cache or environment variable
# This ensures operations are ALWAYS tied to the authenticated user
def get_cached_username():
    """
    Get username from session cache if available.
    CRITICAL: No hardcoded fallback - operations must be user-specific!
    """
    # First, try environment variable (for manual script usage)
    env_username = os.environ.get('NSX_USERNAME')
    if env_username:
        return env_username
    
    # Second, try session cache (for web app usage)
    try:
        project_root = Path(__file__).resolve().parents[1]
        cache_file = project_root / "data" / "nsx_session_cache.json"
        if cache_file.exists():
            with open(cache_file, 'r') as f:
                cache_data = json.load(f)
                # Get username from first cached session
                for env_data in cache_data.values():
                    if 'username' in env_data:
                        return env_data['username']
    except Exception:
        pass
    
    # NO FALLBACK - if no username found, return None
    # This forces authentication before operations can proceed
    return None

USERNAME = get_cached_username()

# Get NSX IP from environment variable or use default
NSX_IP = os.environ.get('NSX_IP', "10.190.200.3")
NSX_ENV = os.environ.get('NSX_ENV', "UK")

BASE_URL = f"https://{NSX_IP}"
LOGIN_URL = f"{BASE_URL}/api/session/create"

def get_nsx_environments():
    """
    Load NSX environments from the configuration file
    """
    try:
        # Path to environments config file
        current_dir = Path(__file__).parent.parent
        config_path = current_dir / 'data' / 'nsx_environments.json'
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
                return config_data.get('environments', [])
        else:
            # Return default environments if config doesn't exist
            return [
                {"name": "NSX-T UK", "ip": "10.190.200.3", "environment": "UK", "status": "configured"},
                {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US", "status": "configured"},
                {"name": "NSX-T EU", "ip": "10.55.0.3", "environment": "EU", "status": "configured"}
            ]
    except Exception as e:
        print(f"[!] Error reading environments config: {e}")
        # Return default environments as fallback
        return [
            {"name": "NSX-T UK", "ip": "10.190.200.3", "environment": "UK", "status": "configured"},
            {"name": "NSX-T US", "ip": "10.148.0.3", "environment": "US", "status": "configured"},
            {"name": "NSX-T EU", "ip": "10.55.0.3", "environment": "EU", "status": "configured"}
        ]

def refresh_config():
    """
    Refresh configuration from environment variables - call this after env vars change
    """
    global NSX_IP, NSX_ENV, BASE_URL, LOGIN_URL
    NSX_IP = os.environ.get('NSX_IP', "10.190.200.3")
    NSX_ENV = os.environ.get('NSX_ENV', "UK")
    BASE_URL = f"https://{NSX_IP}"
    LOGIN_URL = f"{BASE_URL}/api/session/create"

def get_nsx_display_name():
    """
    Get a display name for the current NSX environment from dynamic config
    """
    environments = get_nsx_environments()
    
    for env in environments:
        if env['ip'] == NSX_IP:
            return env['name']
    
    # Fallback if not found in config
    return f"NSX-T ({NSX_IP})"

def get_environment_by_ip(ip):
    """
    Get environment configuration by IP address
    """
    environments = get_nsx_environments()
    
    for env in environments:
        if env['ip'] == ip:
            return env
    
    return None

def login_to_nsx():
    """
    Login to NSX-T and return the authenticated session
    """
    nsx_name = get_nsx_display_name()
    
    # Prompt for password securely
    password = getpass.getpass(f"Enter password for {USERNAME} on {nsx_name}: ")
    
    # Create session
    session = requests.Session()
    
    print(f"[*] Logging into {nsx_name} at {NSX_IP}...")
    
    # Prepare login payload
    login_payload = {
        "j_username": USERNAME,
        "j_password": password
    }
    
    login_headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    
    try:
        # Attempt login
        login_response = session.post(
            LOGIN_URL, 
            data=login_payload, 
            headers=login_headers, 
            verify=False,
            timeout=30
        )
        
        if login_response.status_code != 200:
            print(f"[!] Login failed ({login_response.status_code})")
            print(f"[!] Response: {login_response.text}")
            return None
        
        print("[+] Login successful!")
        
        # Handle XSRF token for session-based authentication
        xsrf_token = login_response.headers.get("X-XSRF-TOKEN")
        if xsrf_token:
            session.headers.update({"X-XSRF-TOKEN": xsrf_token})
            print(f"[+] XSRF token captured: {xsrf_token[:20]}...")
        
        return session
        
    except requests.exceptions.RequestException as e:
        print(f"[!] Connection error: {e}")
        return None

def test_connection(session):
    """
    Test the connection by making a simple API call
    """
    if not session:
        return False
        
    try:
        # Test with a simple API call - get system information
        test_url = f"{BASE_URL}/api/v1/cluster/status"
        response = session.get(test_url, verify=False, timeout=10)
        
        if response.status_code == 200:
            print("[+] Connection test successful!")
            return True
        else:
            print(f"[!] Connection test failed ({response.status_code})")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[!] Connection test error: {e}")
        return False

def main():
    """
    Main function
    """
    nsx_name = get_nsx_display_name()
    print(f"NSX-T Login Script - {nsx_name}")
    print("=" * 50)
    
    # Login to NSX
    session = login_to_nsx()
    
    if session:
        # Test the connection
        if test_connection(session):
            print(f"[+] Ready for NSX-T API operations on {nsx_name}!")
            return session
        else:
            print("[!] Session established but connection test failed")
            return None
    else:
        print("[!] Failed to establish session")
        return None

if __name__ == "__main__":
    session = main()
    if session:
        print("\n[*] Session object is available for further API calls")
        print("[*] Use 'session.get()', 'session.post()', etc. for API requests")
    else:
        sys.exit(1)