#!/usr/bin/env python3
"""
NSX-T Service Creation Script
Creates services in NSX-T with session token caching functionality
"""

import requests
import urllib3
import json
import os
import time
from datetime import datetime, timedelta
import getpass
import sys

# Import our login module
from .NSX_login import login_to_nsx, USERNAME, NSX_IP, BASE_URL, NSX_ENV, get_nsx_display_name

# Disable SSL warnings for self-signed certificates
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Consolidated token cache file for all NSX environments
import os as _os
TOKEN_CACHE_FILE = _os.path.join(_os.path.dirname(_os.path.dirname(__file__)), "data", "nsx_session_cache.json")

def get_current_user_from_cache(nsx_env, nsx_ip):
    """
    Get the username associated with the current cached session for an environment.
    This is used for audit logging and operation tracking.
    
    Returns:
        str: Username of the authenticated user, or "unknown_user" if not found
    """
    try:
        if not os.path.exists(TOKEN_CACHE_FILE):
            return "unknown_user"
            
        with open(TOKEN_CACHE_FILE, 'r') as f:
            cache_data = json.load(f)
        
        env_key = f"{nsx_env}_{nsx_ip}"
        if env_key in cache_data:
            return cache_data[env_key].get("username", "unknown_user")
        
        return "unknown_user"
    except Exception:
        return "unknown_user"

def save_session_to_cache(session, xsrf_token):
    """
    Save session cookies and XSRF token to consolidated cache file with expiration
    
    IMPORTANT: USERNAME must be set before calling this function!
    Operations will be tracked by this username.
    """
    try:
        # Cache duration aligned with typical NSX session lifetime (25 min with buffer)
        expiry_time = datetime.now() + timedelta(minutes=25)

        # Load existing cache data
        cache_data = {}
        if os.path.exists(TOKEN_CACHE_FILE):
            try:
                with open(TOKEN_CACHE_FILE, 'r') as f:
                    cache_data = json.load(f)
            except:
                cache_data = {}

        # Create environment key
        env_key = f"{NSX_ENV}_{NSX_IP}"
        
        # CRITICAL: Store username for operation tracking and audit logging
        # If USERNAME is None, we should not save the session
        if USERNAME is None:
            print(f"[!] WARNING: Cannot save session - no username available!")
            print(f"[!] Set NSX_USERNAME environment variable or authenticate via web UI")
            return False

        # Store session data for this environment
        cache_data[env_key] = {
            "cookies": dict(session.cookies),
            "xsrf_token": xsrf_token,
            "expiry": expiry_time.isoformat(),
            "username": USERNAME,  # Used for operation tracking and audit
            "nsx_ip": NSX_IP,
            "nsx_env": NSX_ENV
        }

        with open(TOKEN_CACHE_FILE, 'w') as f:
            json.dump(cache_data, f, indent=2)

        print(f"[TOKEN] Cached session for {NSX_ENV} (user: {USERNAME}) until {expiry_time.strftime('%H:%M:%S')}")
        return True

    except Exception as e:
        print(f"[!] Failed to save session cache: {e}")
        return False

def load_session_from_cache():
    """
    Load session from consolidated cache file if valid and not expired
    
    IMPORTANT: This function does NOT validate username anymore!
    Each cached session is valid for the user who created it.
    Operations are attributed to the user whose token is being used.
    """
    try:
        if not os.path.exists(TOKEN_CACHE_FILE):
            print("[*] No cached session found")
            return None
            
        with open(TOKEN_CACHE_FILE, 'r') as f:
            cache_data = json.load(f)
        
        # Create environment key
        env_key = f"{NSX_ENV}_{NSX_IP}"
        
        # Check if we have data for this environment
        if env_key not in cache_data:
            print(f"[TOKEN] No cached session found for {NSX_ENV}")
            return None
            
        env_cache = cache_data[env_key]
        
        # REMOVED: Username validation check
        # The cached session belongs to whoever authenticated
        # Operations will be tracked by the username stored in the cache
        cached_username = env_cache.get("username", "unknown_user")
        print(f"[TOKEN] Loading cached session for user: {cached_username}")
        
        # Check expiry
        expiry_time = datetime.fromisoformat(env_cache["expiry"])
        if datetime.now() >= expiry_time:
            print(f"[TOKEN] Cached session for {NSX_ENV} has expired at {expiry_time.strftime('%H:%M:%S')}")
            # Remove this environment's cache
            del cache_data[env_key]
            with open(TOKEN_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            return None
        
        # Recreate session
        session = requests.Session()
        
        # Restore cookies
        for name, value in env_cache["cookies"].items():
            session.cookies.set(name, value)
        
        # Restore XSRF token
        if env_cache.get("xsrf_token"):
            session.headers.update({"X-XSRF-TOKEN": env_cache["xsrf_token"]})

        # Test the session with both management and policy APIs
        # First test management API
        test_mgmt_url = f"{BASE_URL}/api/v1/cluster/status"
        mgmt_response = session.get(test_mgmt_url, verify=False, timeout=10)

        # Then test policy API access (use concrete endpoint that we actually call)
        test_policy_url = f"{BASE_URL}/policy/api/v1/infra/domains/default/security-policies"
        policy_response = session.get(test_policy_url, verify=False, timeout=10)

        print(f"[TOKEN] Cache probe -> mgmt={mgmt_response.status_code}, policy={policy_response.status_code}")

        if mgmt_response.status_code == 200:
            if policy_response.status_code == 200:
                print(f"[TOKEN] CACHE_HIT {NSX_ENV}: using cached session (valid until {expiry_time.strftime('%H:%M:%S')}); mgmt+policy OK")
                return session
            else:
                print(f"[TOKEN] CACHE_HIT {NSX_ENV}: policy probe failed (status={policy_response.status_code}); using cached session (mgmt-only)")
                return session
        else:
            print(f"[TOKEN] Cached session for {NSX_ENV} is invalid (mgmt={mgmt_response.status_code})")
            # Remove this environment's cache
            del cache_data[env_key]
            with open(TOKEN_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            return None
            
    except Exception as e:
        print(f"[!] Failed to load cached session: {e}")
        return None

def clear_session_cache():
    """
    Clear cached session for current environment
    """
    try:
        if os.path.exists(TOKEN_CACHE_FILE):
            with open(TOKEN_CACHE_FILE, 'r') as f:
                cache_data = json.load(f)
            
            env_key = f"{NSX_ENV}_{NSX_IP}"
            if env_key in cache_data:
                del cache_data[env_key]
                with open(TOKEN_CACHE_FILE, 'w') as f:
                    json.dump(cache_data, f, indent=2)
                print(f"[+] Cleared cached session for {NSX_ENV}")
    except Exception as e:
        print(f"[!] Failed to clear session cache: {e}")

def get_authenticated_session(require_policy_access: bool = False):
    """
    Get authenticated session from cache ONLY - NEVER prompts for password.
    This is designed for web app usage where interactive prompts are not possible.
    
    If no valid cached session exists, raises an AuthenticationRequiredError
    which the web app should catch and return a 401 to trigger re-login.
    
    When require_policy_access=True, verifies policy API access and clears
    cache if it fails (forcing re-authentication via web login).
    """
    # CRITICAL: Refresh NSX configuration before any session operations
    from . import NSX_login
    NSX_login.refresh_config()
    
    # Get the refreshed values
    current_nsx_ip = NSX_login.NSX_IP
    current_nsx_env = NSX_login.NSX_ENV
    current_base_url = NSX_login.BASE_URL
    
    print(f"[TOKEN] Session management start env={current_nsx_env} ip={current_nsx_ip} require_policy_access={require_policy_access}")
    
    # Try to load cached session with current config
    session = load_session_from_cache_with_config(current_nsx_ip, current_nsx_env, current_base_url)
    if session:
        if require_policy_access:
            # Verify policy API works; if not, clear cache for this env and re-auth
            test_policy_url = f"{current_base_url}/policy/api/v1/infra/domains/default/security-policies"
            try:
                policy_resp = session.get(test_policy_url, verify=False, timeout=10)
                if policy_resp.status_code != 200:
                    print(f"[TOKEN] POLICY_PROBE_FAIL cached env={current_nsx_env} status={policy_resp.status_code} -> clearing cache")
                    clear_session_cache_with_config(current_nsx_ip, current_nsx_env)
                    # Raise exception to force web login
                    raise AuthenticationRequiredError(f"Policy API access failed for {current_nsx_env}. Please log in again.")
                else:
                    print(f"[TOKEN] POLICY_PROBE_OK cached env={current_nsx_env}")
                    return session
            except AuthenticationRequiredError:
                raise  # Re-raise our own exception
            except Exception as e:
                print(f"[TOKEN] POLICY_PROBE_ERROR cached env={current_nsx_env}: {e} -> clearing cache")
                clear_session_cache_with_config(current_nsx_ip, current_nsx_env)
                raise AuthenticationRequiredError(f"Policy API probe failed for {current_nsx_env}: {str(e)}. Please log in again.")
        else:
            print(f"[TOKEN] CACHE_HIT env={current_nsx_env} (policy not required)")
            return session
    
    # No cached session available - raise exception to force web login
    print(f"[TOKEN] CACHE_MISS env={current_nsx_env} -> Authentication required")
    raise AuthenticationRequiredError(f"No valid session for {current_nsx_env}. Please log in.")


class AuthenticationRequiredError(Exception):
    """
    Raised when authentication is required but not available.
    Web app should catch this and return 401 to trigger login flow.
    """
    pass

def clear_session_cache_with_config(nsx_ip: str, nsx_env: str):
    """Remove cached session for a specific environment key."""
    try:
        if os.path.exists(TOKEN_CACHE_FILE):
            with open(TOKEN_CACHE_FILE, 'r') as f:
                cache_data = json.load(f)
        else:
            return
        env_key = f"{nsx_env}_{nsx_ip}"
        if env_key in cache_data:
            del cache_data[env_key]
            with open(TOKEN_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            print(f"[+] Cleared cached session for {nsx_env} ({nsx_ip})")
    except Exception as e:
        print(f"[!] Failed to clear cached session for {nsx_env}: {e}")

def load_session_from_cache_with_config(nsx_ip, nsx_env, base_url):
    """
    Load session from cache using explicit configuration parameters
    """
    try:
        if not os.path.exists(TOKEN_CACHE_FILE):
            print(f"[TOKEN] No cached session found for {nsx_env}")
            return None
            
        with open(TOKEN_CACHE_FILE, 'r') as f:
            cache_data = json.load(f)
        
        # Create environment key
        env_key = f"{nsx_env}_{nsx_ip}"
        
        # Check if we have data for this environment
        if env_key not in cache_data:
            print(f"[TOKEN] No cached session found for {nsx_env}")
            return None
            
        env_cache = cache_data[env_key]
        
        # Get cached username for logging (no validation against hardcoded username)
        cached_username = env_cache.get("username", "unknown_user")
        
        # Check expiry
        expiry_time = datetime.fromisoformat(env_cache["expiry"])
        now = datetime.now()
        if now >= expiry_time:
            print(f"[TOKEN] Cached session for {nsx_env} expired at {expiry_time.strftime('%H:%M:%S')} (now {now.strftime('%H:%M:%S')})")
            # Remove this environment's cache
            del cache_data[env_key]
            with open(TOKEN_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            return None
        else:
            remaining = int((expiry_time - now).total_seconds())
            print(f"[TOKEN] Cache candidate env={nsx_env} user={cached_username} expires_in={remaining}s")
        
        # Recreate session
        session = requests.Session()
        
        # Restore cookies
        for name, value in env_cache["cookies"].items():
            session.cookies.set(name, value)
        
        # Restore XSRF token
        if env_cache.get("xsrf_token"):
            session.headers.update({"X-XSRF-TOKEN": env_cache["xsrf_token"]})
        
        # Test the session with the CORRECT base URL
        # Log detailed debug info to file only (use relative path)
        try:
            log_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "all of the terminal output.txt")
            with open(log_file, "a") as debug_log:
                debug_log.write(f"[TOKEN] Testing cached session for {nsx_env} at {nsx_ip}\n")
        except:
            pass  # Ignore logging errors
        
        # Test management API
        test_mgmt_url = f"{base_url}/api/v1/cluster/status"
        mgmt_response = session.get(test_mgmt_url, verify=False, timeout=10)
        
        # Test policy API access
        test_policy_url = f"{base_url}/policy/api/v1/infra/domains/default/security-policies"
        policy_response = session.get(test_policy_url, verify=False, timeout=10)
        
        # Log to file only (use relative path)
        try:
            log_file = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "all of the terminal output.txt")
            with open(log_file, "a") as debug_log:
                debug_log.write(f"[TOKEN] Management API status: {mgmt_response.status_code}\n")
                debug_log.write(f"[TOKEN] Policy API status: {policy_response.status_code}\n")
        except:
            pass  # Ignore logging errors
        
        if mgmt_response.status_code == 200:
            if policy_response.status_code == 200:
                print(f"[TOKEN] CACHE_HIT {nsx_env}: using cached session (mgmt+policy OK)")
                return session
            else:
                print(f"[TOKEN] CACHE_HIT {nsx_env}: using cached session (limited policy access)")
                return session
        else:
            print(f"[TOKEN] Cached session for {nsx_env} invalid (mgmt={mgmt_response.status_code}); will re-authenticate…")
            # Remove this environment's cache
            del cache_data[env_key]
            with open(TOKEN_CACHE_FILE, 'w') as f:
                json.dump(cache_data, f, indent=2)
            return None
            
    except Exception as e:
        print(f"[!] Failed to load cached session: {e}")
        return None

def save_session_to_cache_with_config(session, xsrf_token, nsx_ip, nsx_env):
    """
    Save session to cache using explicit configuration parameters
    """
    try:
        # Cache for 25 minutes to cover end-to-end runs without repeated prompts
        expiry_time = datetime.now() + timedelta(minutes=25)
        
        # Load existing cache data
        cache_data = {}
        if os.path.exists(TOKEN_CACHE_FILE):
            try:
                with open(TOKEN_CACHE_FILE, 'r') as f:
                    cache_data = json.load(f)
            except:
                cache_data = {}
        
        # Create environment key
        env_key = f"{nsx_env}_{nsx_ip}"
        
        # Store session data for this environment
        cache_data[env_key] = {
            "cookies": dict(session.cookies),
            "xsrf_token": xsrf_token,
            "expiry": expiry_time.isoformat(),
            "username": USERNAME,
            "nsx_ip": nsx_ip,
            "nsx_env": nsx_env
        }
        
        # Save to file
        with open(TOKEN_CACHE_FILE, 'w') as f:
            json.dump(cache_data, f, indent=2)

        print(f"[TOKEN] Cached session for {nsx_env} until {expiry_time.strftime('%H:%M:%S')}")
        return True
        
    except Exception as e:
        print(f"[!] Failed to save session cache: {e}")
        return False

def sanitize_service_id(service_name):
    """
    Convert service name to valid service ID
    """
    # Remove special characters and spaces, convert to lowercase
    service_id = service_name.lower().replace(" ", "-").replace("_", "-")
    # Remove any character that's not alphanumeric or dash
    service_id = ''.join(c for c in service_id if c.isalnum() or c == '-')
    # Remove consecutive dashes
    while '--' in service_id:
        service_id = service_id.replace('--', '-')
    # Remove leading/trailing dashes
    service_id = service_id.strip('-')
    return service_id

def get_service_details():
    """
    Prompt user for service details
    """
    print("\n" + "=" * 50)
    print("NSX-T Service Creation")
    print("=" * 50)
    
    service_name = input("Enter service name: ").strip()
    if not service_name:
        print("[!] Service name cannot be empty")
        return None
    
    service_id = sanitize_service_id(service_name)
    print(f"[*] Service ID will be: {service_id}")
    
    description = input(f"Enter description (optional): ").strip()
    if not description:
        description = f"Custom service: {service_name}"
    
    print("\nService Entry Configuration:")
    print("1. TCP Port")
    print("2. UDP Port") 
    print("3. TCP Port Range")
    print("4. UDP Port Range")
    
    entry_type = input("Select service entry type (1-4): ").strip()
    
    if entry_type in ["1", "2"]:
        protocol = "TCP" if entry_type == "1" else "UDP"
        port = input(f"Enter {protocol} port number: ").strip()
        try:
            port_num = int(port)
            if not (1 <= port_num <= 65535):
                raise ValueError("Port must be between 1 and 65535")
            ports = [str(port_num)]
        except ValueError as e:
            print(f"[!] Invalid port: {e}")
            return None
            
    elif entry_type in ["3", "4"]:
        protocol = "TCP" if entry_type == "3" else "UDP"
        port_range = input(f"Enter {protocol} port range (e.g., 8080-8090): ").strip()
        try:
            if '-' not in port_range:
                raise ValueError("Port range must contain a dash (e.g., 8080-8090)")
            start_port, end_port = port_range.split('-')
            start_port = int(start_port.strip())
            end_port = int(end_port.strip())
            if not (1 <= start_port <= 65535) or not (1 <= end_port <= 65535):
                raise ValueError("Ports must be between 1 and 65535")
            if start_port >= end_port:
                raise ValueError("Start port must be less than end port")
            ports = [f"{start_port}-{end_port}"]
        except ValueError as e:
            print(f"[!] Invalid port range: {e}")
            return None
    else:
        print("[!] Invalid selection")
        return None
    
    return {
        "service_id": service_id,
        "service_name": service_name,
        "description": description,
        "protocol": protocol,
        "ports": ports
    }

def create_service(session, service_details):
    """
    Create the service in NSX-T
    """
    service_id = service_details["service_id"]
    
    # Construct service URL
    service_url = f"{BASE_URL}/policy/api/v1/infra/services/{service_id}"
    
    # Construct service payload
    service_payload = {
        "resource_type": "Service",
        "display_name": service_details["service_name"],
        "description": service_details["description"],
        "service_entries": [
            {
                "resource_type": "L4PortSetServiceEntry",
                "display_name": f"{service_details['service_name']}-entry",
                "destination_ports": service_details["ports"],
                "l4_protocol": service_details["protocol"]
            }
        ]
    }
    
    print(f"\n[*] Creating service: {service_details['service_name']}")
    print(f"[*] Service ID: {service_id}")
    print(f"[*] Protocol: {service_details['protocol']}")
    print(f"[*] Ports: {', '.join(service_details['ports'])}")
    
    try:
        # Make the API call - Use PATCH for creating new services
        response = session.patch(
            service_url,
            json=service_payload,
            verify=False,
            timeout=30,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code in [200, 201]:
            print("[+] Service created successfully!")
            
            # Parse response - some NSX APIs return empty response body
            try:
                if response.text.strip():
                    service_data = response.json()
                    print(f"[+] Service path: {service_data.get('path', f'/infra/services/{service_id}')}")
                    print(f"[+] Service revision: {service_data.get('_revision', 'N/A')}")
                else:
                    print(f"[+] Service path: /infra/services/{service_id}")
                    print(f"[+] Service created (empty response)")
            except json.JSONDecodeError:
                print(f"[+] Service path: /infra/services/{service_id}")
                print(f"[+] Service created (non-JSON response)")
            
            # Verify the service actually exists by making a GET request
            print(f"[*] Verifying service creation...")
            verify_response = session.get(service_url, verify=False, timeout=30)
            
            if verify_response.status_code == 200:
                print(f"[+] ✅ Service verification successful!")
                verify_data = verify_response.json()
                print(f"[+] Service display name: {verify_data.get('display_name')}")
                print(f"[+] Service entries: {len(verify_data.get('service_entries', []))}")
                
                # Also verify it appears in the services list
                print(f"[*] Checking if service appears in services list...")
                services_response = session.get(f"{BASE_URL}/policy/api/v1/infra/services", verify=False, timeout=30)
                if services_response.status_code == 200:
                    services_data = services_response.json()
                    all_services = services_data.get("results", [])
                    service_found = any(s.get('id') == service_id for s in all_services)
                    if service_found:
                        print(f"[+] ✅ Service found in services list!")
                    else:
                        print(f"[!] ⚠️  Service not found in services list (may need refresh)")
                
                return True
            else:
                print(f"[!] ❌ Service verification failed ({verify_response.status_code})")
                print(f"[!] The service may not have been created properly")
                print(f"[!] Verification response: {verify_response.text}")
                return False
            
        else:
            print(f"[!] Failed to create service ({response.status_code})")
            print(f"[!] Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"[!] Connection error: {e}")
        return False

def list_existing_services(session):
    """
    List existing custom services
    """
    try:
        services_url = f"{BASE_URL}/policy/api/v1/infra/services?default_service=false"
        response = session.get(services_url, verify=False, timeout=30)
        
        if response.status_code == 200:
            services_data = response.json()
            services = services_data.get("results", [])
            
            if services:
                print(f"\n[*] Found {len(services)} existing custom services:")
                for service in services[:10]:  # Show first 10
                    print(f"  - {service.get('display_name')} (ID: {service.get('id')})")
                if len(services) > 10:
                    print(f"  ... and {len(services) - 10} more")
            else:
                print("\n[*] No existing custom services found")
                
        else:
            print(f"[!] Failed to list services ({response.status_code})")
            
    except requests.exceptions.RequestException as e:
        print(f"[!] Error listing services: {e}")

def main():
    """
    Main function
    """
    nsx_name = get_nsx_display_name()
    print(f"NSX-T Service Creation Tool - {nsx_name}")
    print("=" * 50)
    
    # Get authenticated session
    session = get_authenticated_session()
    if not session:
        print("[!] Failed to authenticate to NSX-T")
        print("[!] Please check your credentials and network connectivity")
        print("[!] Returning to main menu...")
        return False
    
    # List existing services
    list_existing_services(session)
    
    # Get service details from user
    service_details = get_service_details()
    if not service_details:
        print("[!] Invalid service configuration")
        return False
    
    # Create the service
    success = create_service(session, service_details)
    
    if success:
        print(f"\n[+] Service '{service_details['service_name']}' created successfully!")
        print(f"[*] You can now use this service in firewall rules")
        print(f"[*] Service path: /infra/services/{service_details['service_id']}")
        return True
    else:
        print(f"\n[!] Failed to create service '{service_details['service_name']}'")
        return False

if __name__ == "__main__":
    main()
