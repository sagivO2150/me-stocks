"""
Extensive Logger for NSX Policy Replication System
Provides comprehensive debugging logs with context window management
All extensive debugging logs go to: /webapp/logs/extensive log file.log
"""

import logging
import logging.handlers
import os
import threading
from datetime import datetime
from pathlib import Path

class ExtensiveLogger:
    """
    Singleton logger for extensive debugging across all NSX components
    Automatically manages log file size to fit context window (100KB max)
    """
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
            
        # Set up the extensive log file path using relative path
        PROJECT_ROOT = Path(__file__).resolve().parents[2]
        log_dir = str(PROJECT_ROOT / "webapp" / "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        log_file_path = os.path.join(log_dir, "extensive log file.log")
        
        # Create logger
        self.logger = logging.getLogger('extensive_nsx_logger')
        self.logger.setLevel(logging.DEBUG)
        
        # Clear any existing handlers
        self.logger.handlers.clear()
        
        # Create rotating file handler (100KB max, 1 backup to fit context window)
        file_handler = logging.handlers.RotatingFileHandler(
            log_file_path,
            maxBytes=100 * 1024,  # 100KB
            backupCount=1,
            encoding='utf-8'
        )
        
        # Create detailed formatter for debugging
        formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(component)-20s | %(session)-25s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        
        # Add handler to logger
        self.logger.addHandler(file_handler)
        
        # Track current session
        self.current_session = None
        self._initialized = True
        
        # Log initialization
        self.info("extensive_logger", "Extensive logger initialized - all debugging logs go to webapp/logs/extensive log file.log")
    
    def _log(self, level, component, message, session=None):
        """Internal logging method with component and session tracking"""
        if session is None:
            session = self.current_session or "no_session"
            
        # Create log record with custom fields
        record = self.logger.makeRecord(
            name=self.logger.name,
            level=level,
            fn="",
            lno=0,
            msg=message,
            args=(),
            exc_info=None
        )
        record.component = component
        record.session = session
        
        self.logger.handle(record)
    
    def debug(self, component, message, session=None):
        """Log debug message"""
        self._log(logging.DEBUG, component, message, session)
    
    def info(self, component, message, session=None):
        """Log info message"""
        self._log(logging.INFO, component, message, session)
    
    def warning(self, component, message, session=None):
        """Log warning message"""
        self._log(logging.WARNING, component, message, session)
    
    def error(self, component, message, session=None):
        """Log error message"""
        self._log(logging.ERROR, component, message, session)
    
    def session_start(self, component, session_name):
        """Start a new session for tracking related operations"""
        session_id = f"{component}_{session_name}_{datetime.now().strftime('%H%M%S')}"
        self.current_session = session_id
        self.info(component, f"=== SESSION START: {session_name} ===", session_id)
        return session_id
    
    def session_end(self, component, session_name, success=True):
        """End the current session"""
        status = "SUCCESS" if success else "FAILED"
        session_id = self.current_session
        self.info(component, f"=== SESSION END: {session_name} - {status} ===", session_id)
        self.current_session = None
        return session_id

# Global instance for easy import
extensive_log = ExtensiveLogger()
