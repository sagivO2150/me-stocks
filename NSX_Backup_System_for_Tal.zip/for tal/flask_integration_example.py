#!/usr/bin/env python3
"""
Simple Example: How to integrate NSX Backup into your Flask application
This shows the basic pattern for triggering backups and loading backup data
"""

from flask import Flask, jsonify, request
import subprocess
import json
from pathlib import Path
from datetime import datetime
import threading

app = Flask(__name__)

# Configuration
BACKUP_SCRIPT = Path(__file__).parent / 'backup_system' / 'create_backup.py'
BACKUP_DIR = Path(__file__).parent / 'backup_system' / 'nsx_backups'

# Track backup status
backup_status = {
    'running': False,
    'last_run': None,
    'last_result': None
}


def run_backup_async():
    """Run backup in background thread"""
    global backup_status
    
    try:
        backup_status['running'] = True
        
        result = subprocess.run(
            ['python3', str(BACKUP_SCRIPT)],
            capture_output=True,
            text=True,
            timeout=600  # 10 minute timeout
        )
        
        backup_status['running'] = False
        backup_status['last_run'] = datetime.now().isoformat()
        backup_status['last_result'] = {
            'success': result.returncode == 0,
            'stdout': result.stdout[-500:] if result.stdout else '',  # Last 500 chars
            'stderr': result.stderr[-500:] if result.stderr else ''
        }
        
    except subprocess.TimeoutExpired:
        backup_status['running'] = False
        backup_status['last_run'] = datetime.now().isoformat()
        backup_status['last_result'] = {
            'success': False,
            'error': 'Backup timed out after 10 minutes'
        }
    except Exception as e:
        backup_status['running'] = False
        backup_status['last_run'] = datetime.now().isoformat()
        backup_status['last_result'] = {
            'success': False,
            'error': str(e)
        }


@app.route('/api/trigger_backup', methods=['POST'])
def trigger_backup():
    """
    Trigger NSX backup refresh
    Called when user clicks "Refresh" button
    """
    if backup_status['running']:
        return jsonify({
            'success': False,
            'error': 'Backup already in progress'
        }), 409
    
    # Start backup in background thread
    thread = threading.Thread(target=run_backup_async)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'success': True,
        'message': 'Backup started',
        'status': 'running'
    })


@app.route('/api/backup_status', methods=['GET'])
def get_backup_status():
    """
    Get current backup status
    Useful for polling to show progress in UI
    """
    return jsonify({
        'running': backup_status['running'],
        'last_run': backup_status['last_run'],
        'last_result': backup_status['last_result']
    })


@app.route('/api/environments', methods=['GET'])
def get_environments():
    """
    Get list of available NSX environments with backup info
    """
    environments = []
    
    for backup_file in BACKUP_DIR.glob("*_complete_backup.json"):
        env_code = backup_file.stem.split('_')[0].upper()
        
        try:
            with open(backup_file, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            environments.append({
                'code': env_code,
                'name': backup_data['environment']['name'],
                'ip': backup_data['environment']['ip'],
                'backup_timestamp': backup_data['backup_timestamp'],
                'statistics': backup_data['statistics']
            })
        except Exception as e:
            # If backup file is corrupted, still show environment
            environments.append({
                'code': env_code,
                'name': f'NSX-T {env_code}',
                'error': f'Failed to load backup: {str(e)}'
            })
    
    return jsonify({
        'success': True,
        'environments': environments,
        'count': len(environments)
    })


@app.route('/api/policies/<env_code>', methods=['GET'])
def get_policies(env_code):
    """
    Get all policies for a specific environment
    """
    backup_file = BACKUP_DIR / f'{env_code}_complete_backup.json'
    
    if not backup_file.exists():
        return jsonify({
            'success': False,
            'error': f'No backup found for environment {env_code}'
        }), 404
    
    try:
        with open(backup_file, 'r', encoding='utf-8') as f:
            backup_data = json.load(f)
        
        policies = backup_data.get('policies', [])
        
        # Optional: Filter out system policies if needed
        user_policies = [p for p in policies if not p.get('_system_owned', False)]
        
        return jsonify({
            'success': True,
            'environment': env_code,
            'total_policies': len(policies),
            'user_policies': len(user_policies),
            'policies': policies
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/groups/<env_code>', methods=['GET'])
def get_groups(env_code):
    """
    Get all groups for a specific environment
    """
    backup_file = BACKUP_DIR / f'{env_code}_complete_backup.json'
    
    if not backup_file.exists():
        return jsonify({
            'success': False,
            'error': f'No backup found for environment {env_code}'
        }), 404
    
    try:
        with open(backup_file, 'r', encoding='utf-8') as f:
            backup_data = json.load(f)
        
        groups_data = backup_data.get('groups', {})
        
        return jsonify({
            'success': True,
            'environment': env_code,
            'all_groups': groups_data.get('all_groups', []),
            'user_groups': groups_data.get('user_groups', []),
            'system_groups': groups_data.get('system_groups', []),
            'counts': {
                'all': len(groups_data.get('all_groups', [])),
                'user': len(groups_data.get('user_groups', [])),
                'system': len(groups_data.get('system_groups', []))
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/services/<env_code>', methods=['GET'])
def get_services(env_code):
    """
    Get all services for a specific environment
    """
    backup_file = BACKUP_DIR / f'{env_code}_complete_backup.json'
    
    if not backup_file.exists():
        return jsonify({
            'success': False,
            'error': f'No backup found for environment {env_code}'
        }), 404
    
    try:
        with open(backup_file, 'r', encoding='utf-8') as f:
            backup_data = json.load(f)
        
        services_data = backup_data.get('services', {})
        
        return jsonify({
            'success': True,
            'environment': env_code,
            'all_services': services_data.get('all_services', []),
            'user_services': services_data.get('user_services', []),
            'default_services': services_data.get('default_services', []),
            'system_services': services_data.get('system_services', []),
            'counts': {
                'all': len(services_data.get('all_services', [])),
                'user': len(services_data.get('user_services', [])),
                'default': len(services_data.get('default_services', [])),
                'system': len(services_data.get('system_services', []))
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/')
def index():
    """Simple index page"""
    return """
    <html>
    <head><title>NSX Backup API</title></head>
    <body>
        <h1>NSX Backup System - API Example</h1>
        <h2>Available Endpoints:</h2>
        <ul>
            <li><code>POST /api/trigger_backup</code> - Start backup refresh</li>
            <li><code>GET /api/backup_status</code> - Check backup status</li>
            <li><code>GET /api/environments</code> - List all environments</li>
            <li><code>GET /api/policies/&lt;env_code&gt;</code> - Get policies for environment</li>
            <li><code>GET /api/groups/&lt;env_code&gt;</code> - Get groups for environment</li>
            <li><code>GET /api/services/&lt;env_code&gt;</code> - Get services for environment</li>
        </ul>
        <h2>Quick Test:</h2>
        <button onclick="fetch('/api/trigger_backup', {method: 'POST'}).then(r => r.json()).then(d => alert(JSON.stringify(d)))">
            Trigger Backup
        </button>
        <button onclick="fetch('/api/backup_status').then(r => r.json()).then(d => alert(JSON.stringify(d)))">
            Check Status
        </button>
        <button onclick="fetch('/api/environments').then(r => r.json()).then(d => alert(JSON.stringify(d, null, 2)))">
            List Environments
        </button>
    </body>
    </html>
    """


if __name__ == '__main__':
    print("=" * 60)
    print("NSX Backup System - Flask Integration Example")
    print("=" * 60)
    print(f"Backup Script: {BACKUP_SCRIPT}")
    print(f"Backup Directory: {BACKUP_DIR}")
    print("")
    print("Starting Flask server on http://localhost:5000")
    print("=" * 60)
    
    app.run(debug=True, port=5000)
