# NSX-T Backup System Package

This package contains a complete, production-ready NSX-T backup system that fetches security policies, rules, groups, and services from multiple NSX-T environments in parallel.

## 📦 Package Contents

- **NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md** - Comprehensive documentation for developers and AI assistants
- **modules/** - Core authentication and session management
- **backup_system/** - Main backup orchestrator and workers
- **config/** - NSX environment configuration
- **requirements.txt** - Python dependencies

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environments
Edit `config/nsx_environments.json` with your NSX-T manager IPs and credentials.

### 3. Set Username
```bash
export NSX_USERNAME="your_nsx_username"
```

### 4. Run Backup
```bash
cd backup_system
python3 create_backup.py
```

The system will:
- Prompt for your NSX password (first run only)
- Cache the session for 25 minutes
- Back up all configured environments in parallel
- Save JSON files in `backup_system/nsx_backups/`

## 📖 Full Documentation

**Read the complete guide first**: `NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md`

This document contains:
- Complete system architecture explanation
- Step-by-step flow documentation
- Setup instructions
- Code examples for integration
- Troubleshooting guide
- Best practices

## 🔑 Key Features

✅ **Parallel Processing** - All environments backed up simultaneously  
✅ **Session Caching** - No repeated logins, 25-minute cache  
✅ **Rate Limit Handling** - Automatic retry with exponential backoff  
✅ **Data Validation** - Prevents saving empty/corrupt backups  
✅ **High Latency Support** - Optimized for global deployments  
✅ **Production Tested** - Battle-tested in live environments  

## 📊 Performance

- **4 environments backed up in ~30 seconds**
- 8x faster than sequential approach
- Handles 1000+ policies and rules per environment
- Resilient to API rate limiting

## 🤖 AI Assistant Instructions

If you're using GitHub Copilot or another AI coding assistant:

1. **Read the complete guide first**: Open `NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md`
2. The guide is formatted for TTS-friendly reading with natural prose
3. It contains complete flow explanations, not just code snippets
4. Use it to understand the system before making changes

## 🔧 Integration

### From Flask/Web Application
```python
import subprocess
result = subprocess.run(['python3', 'backup_system/create_backup.py'], timeout=600)
```

### Loading Backup Data
```python
import json
with open('backup_system/nsx_backups/UK_complete_backup.json') as f:
    uk_data = json.load(f)
policies = uk_data['policies']
groups = uk_data['groups']['user_groups']
```

## 📝 File Structure

```
NSX_Backup_Package/
├── README.md (this file)
├── NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md
├── requirements.txt
├── modules/
│   ├── NSX_login.py
│   ├── create_service_API.py
│   └── utils/
│       └── extensive_logger.py
├── backup_system/
│   ├── create_backup.py
│   └── backup_workers/
│       ├── backup_uk.py
│       ├── backup_us.py
│       ├── backup_eu.py
│       ├── backup_in.py
│       └── create_backup_worker_optimized.py
└── config/
    └── nsx_environments.json
```

## ⚠️ Important Notes

1. **Session Cache**: The system creates `data/nsx_session_cache.json` - this is normal
2. **Backup Directory**: Creates `backup_system/nsx_backups/` automatically
3. **Passwords**: Never stored - only session tokens are cached
4. **Permissions**: Ensure NSX user has read access to policies/groups/services

## 🆘 Troubleshooting

**Authentication failures?**
- Delete `data/nsx_session_cache.json` and retry
- Verify NSX IPs are reachable
- Check username/password

**Empty backups?**
- Check NSX user permissions
- Look for API rate limiting (HTTP 429)
- See full troubleshooting in the complete guide

**Slow performance?**
- Check network latency to NSX managers
- Verify parallel processing is enabled
- Consider running during off-peak hours

## 📚 Additional Resources

- Original project: API_NSX/create_DC_rules
- Contact: Sagiv (original implementer)
- Commits referenced in guide:
  - 9e3689ef - Auto backup refresh
  - df7e0520 - UI refresh integration
  - 1f1fbda4 - Rate limiting fixes
  - a7f8c20a - Multi-environment filter fix

## 🎯 Next Steps

1. ✅ Read `NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md` thoroughly
2. ✅ Install dependencies: `pip install -r requirements.txt`
3. ✅ Configure your NSX environments in `config/nsx_environments.json`
4. ✅ Run test backup: `cd backup_system && python3 create_backup.py`
5. ✅ Integrate into your web application using examples from the guide

---

**Package Version**: 1.0  
**Date**: February 2026  
**Prepared for**: Tal's NSX Web Application

*This is a complete, self-contained package - everything you need is included!*
