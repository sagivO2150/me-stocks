# NSX-T Backup System - Complete Implementation Guide

## 📋 Table of Contents
1. [Overview](#overview)
2. [System Architecture](#system-architecture)
3. [File Structure](#file-structure)
4. [Complete Flow](#complete-flow)
5. [Setup Instructions](#setup-instructions)
6. [Authentication System](#authentication-system)
7. [Backup Process](#backup-process)
8. [Key Features](#key-features)
9. [Code Examples](#code-examples)
10. [Troubleshooting](#troubleshooting)

---

## 📖 Overview

This NSX-T Backup System provides a complete solution for fetching and caching security policies, rules, groups, and services from multiple NSX-T environments in parallel. The system was built to handle production environments with high latency and rate limiting constraints.

### What This System Does
The backup system connects to multiple NSX-T environments simultaneously and retrieves all security configurations including policies with their rules, security groups, and network services. It handles authentication using session tokens that are cached to avoid repeated logins, processes environments in parallel for maximum speed, and implements retry logic with exponential backoff for handling rate limiting errors from the NSX APIs. The complete backup data is saved as structured JSON files that can be used by web applications for policy management and analysis.

### Key Capabilities
- **Multi-Environment Support**: Backs up UK, US, EU, and IN NSX environments simultaneously
- **Parallel Processing**: Each environment runs in its own process for maximum speed
- **Session Caching**: Reuses authenticated sessions to avoid login overhead
- **Rate Limit Handling**: Automatic retry with exponential backoff for HTTP 429 errors
- **High Latency Support**: Special timeout configurations for geographically distant environments
- **Resource Analysis**: Extracts unique groups and services referenced in security rules
- **Data Validation**: Prevents saving empty backups to avoid data loss

---

## 🏗️ System Architecture

### Components Overview

The system consists of four major components working together. First is the authentication layer which uses NSX login module to establish sessions with NSX-T managers and stores session tokens in a centralized cache file to enable reuse across multiple operations. Second is the orchestration layer with the parallel backup orchestrator that spawns worker processes for each environment and collects results as they complete. Third is the worker layer where individual environment workers handle authentication, API calls, and data collection, implementing retry logic for rate limiting and network errors. Finally there is the data layer which stores backup JSON files in a centralized directory and maintains the session cache for authentication tokens.

### Data Flow

The flow begins when the web application or script calls create backup dot py with no parameters needed. The orchestrator then loads NSX environment configuration from nsx environments dot json and spawns parallel worker processes, one per environment. Each worker authenticates to its assigned NSX-T manager by checking the session cache first, and if no valid session exists or it's expired, it performs a fresh login. After authentication, the worker fetches policies, then rules for each policy concurrently, followed by groups and services in parallel. The worker validates the data to ensure non-empty results before saving to JSON file. Finally, the orchestrator collects all results and prints a summary showing success or failure for each environment with timing statistics.

### Parallel Processing Strategy

The system uses Python's concurrent dot futures ThreadPoolExecutor to run environment backups in parallel. Each environment worker is independent and uses its own session. The orchestrator waits for all workers to complete using as completed iterator. Workers themselves also use parallel processing, fetching rules for multiple policies concurrently and fetching groups and services simultaneously. This multi-level parallelism reduces total backup time from several minutes sequentially to under thirty seconds for all environments.

---

## 📁 File Structure

```
NSX_Backup_Package/
├── NSX_BACKUP_SYSTEM_COMPLETE_GUIDE.md  (this file)
├── modules/
│   ├── NSX_login.py                      # Authentication module
│   └── create_service_API.py             # Session management utilities
├── backup_system/
│   ├── create_backup.py                  # Main orchestrator
│   └── backup_workers/
│       ├── backup_uk.py                  # UK environment worker
│       ├── backup_us.py                  # US environment worker
│       ├── backup_eu.py                  # EU environment worker
│       ├── backup_in.py                  # IN environment worker
│       └── create_backup_worker_optimized.py  # Worker implementation
├── config/
│   └── nsx_environments.json             # Environment configuration
└── requirements.txt                      # Python dependencies
```

---

## 🔄 Complete Flow

### Step 1: Initial Authentication

When the backup system starts, it first needs to authenticate to each NSX-T environment. The authentication process begins by checking if a valid session exists in the session cache file located at data slash nsx session cache dot json. If a valid cached session exists with an expiry time in the future, it loads the session cookies and XSRF token to reuse the existing session. If no valid session exists or the cached session has expired, it performs a new login by prompting for the password securely using getpass, POSTing credentials to the NSX session create endpoint, capturing the session cookies and XSRF token from the response, and caching the new session with a twenty-five minute expiry time.

The session cache is shared across all environments and operations, with each environment identified by a unique key combining environment code and IP address. This means once you authenticate to UK NSX, that session is reused for all subsequent UK operations until it expires.

### Step 2: Parallel Orchestration

The main orchestrator in create backup dot py loads the NSX environments from nsx environments dot json, filtering only environments with status configured. It creates a ThreadPoolExecutor with max workers equal to the number of environments, allowing all backups to run simultaneously. For each environment, it submits a backup task to the executor, passing the environment configuration including name, IP address, and environment code. The orchestrator then waits for results using as completed, which yields results as soon as each worker finishes regardless of submission order. As each worker completes, the orchestrator logs success or failure with timing information and collects all results for the final summary.

### Step 3: Worker Execution

Each environment worker script like backup uk dot py sets environment variables NSX IP and NSX ENV before calling the backup worker implementation. The worker implementation in create backup worker optimized dot py first authenticates using the shared authentication module, then begins fetching data from the NSX-T APIs. It fetches all security policies from the domain, processes policies in batches to fetch rules concurrently using ThreadPoolExecutor with twenty workers, fetches groups and services in parallel using a two-worker pool, and validates that the fetched data is non-empty before proceeding.

The worker implements rate limit handling for groups and services APIs by catching HTTP four twenty nine responses, waiting with exponential backoff for two, four, or six seconds, retrying up to three times before giving up. This was critical for the EU environment which frequently hits rate limits.

### Step 4: Data Collection and Validation

For each policy, the worker fetches its rules by calling the security policies rules endpoint, extracts rule metadata including source and destination exclusions, disabled status, action type, and sequence numbers. It processes policies concurrently with twenty workers to maximize throughput. After fetching all policies and rules, the worker extracts unique groups and services referenced in the rules by parsing source groups and destination groups paths, parsing services including ANY and service paths. This gives visibility into which resources are actually being used versus what exists in NSX.

The worker then fetches all groups and services from NSX in parallel, categorizing groups as user-created or system-owned based on the system owned flag. It categorizes services as user-created, default, or system-owned. Before saving, it validates that groups count and services count are both greater than zero. If both are zero, it throws a fatal error to prevent data loss. This validation caught several authentication and API issues during development.

### Step 5: Backup Storage

Once all data is collected and validated, the worker creates a comprehensive backup data structure containing environment metadata including name, IP, environment code, and display name. It includes backup timestamp in ISO format, detailed statistics showing policy counts, rule counts, group counts, service counts, and backup duration. It includes the full policies array with rules embedded in each policy, the complete groups object with all groups, user groups, and system groups categorized, and the complete services object with all categories. The worker then writes this to a JSON file named environment underscore complete underscore backup dot json in the nsx backups directory, using proper indentation and UTF-8 encoding for readability.

### Step 6: Result Aggregation

After all workers complete or timeout, the orchestrator collects all results and generates a summary. The summary shows total execution time, successful environment count versus total, list of successful backups with file names, and list of failed backups with error messages. This summary is both printed to console and can be returned to calling applications for UI updates.

---

## 🚀 Setup Instructions

### Prerequisites

You need Python three point eight or higher installed on your system. You need network connectivity to NSX-T managers on the configured IP addresses. You need valid NSX-T credentials with read access to policies, rules, groups, and services. And you need sufficient disk space for backup JSON files, approximately ten to fifty megabytes per environment depending on policy count.

### Installation Steps

First, create a project directory structure. Create a directory for your project and subdirectories for modules, backup system, backup workers, config, and data. Then install required Python packages by running pip install requests urllib3 or using the provided requirements dot txt file.

Next, configure your NSX environments by editing config slash nsx environments dot json. Add entries for each NSX-T environment you want to back up. Each entry needs a name like NSX-T UK, an IP address like ten dot one ninety dot two hundred dot three, an environment code like UK, and status set to configured. Only environments with status configured will be backed up.

Set up authentication by setting the NSX USERNAME environment variable to your NSX username, or letting the system prompt you for credentials on first run. The system will cache your session tokens after the first successful login.

Finally, copy the provided files maintaining the directory structure. Ensure modules slash NSX login dot py and modules slash create service API dot py are in the modules directory. Ensure backup system slash create backup dot py is in the backup system directory. And ensure all worker files are in backup system slash backup workers directory.

### Initial Test Run

To test the setup, navigate to the backup system directory and run python3 create backup dot py. The system will prompt for your NSX password on first run, authenticate to all configured environments in parallel, fetch all security configurations, save backup JSON files, and display a summary of results. If successful, you'll see JSON files in backup system slash nsx backups named UK underscore complete underscore backup dot json, US underscore complete underscore backup dot json, and so on.

---

## 🔐 Authentication System

### Session Caching Mechanism

The authentication system uses a centralized session cache to avoid repeated logins. The cache file at data slash nsx session cache dot json stores session data for each environment with a unique key format of environment underscore IP. For each cached session, it stores the session cookies dictionary, the XSRF token string, the expiry timestamp in ISO format, the username for audit tracking, and the environment IP and code.

When any operation needs to authenticate, it first checks this cache. If a valid session exists for the target environment with expiry time in the future, it loads the cached session and reuses it. This dramatically reduces authentication overhead especially during rapid successive operations.

### Authentication Flow

The detailed authentication flow proceeds as follows. First, the system calls get authenticated session from create service API dot py. This function calls load session from cache to check for cached credentials. If a cached session is found and not expired, it creates a new requests session object, updates it with cached cookies, sets the XSRF token header, and returns the session immediately without any network calls.

If no valid cached session exists, it calls login to nsx from NSX login dot py. This prompts for password using getpass, POSTs credentials to api slash session slash create, captures session cookies and XSRF token, and returns an authenticated session. After successful login, it calls save session to cache to store the new session with twenty-five minute expiry. The session is now available for all operations until expiry.

### Security Considerations

The system never stores passwords in cache files, only session tokens. Session tokens automatically expire after twenty-five minutes matching NSX session lifetime. The cache file should have restricted permissions, ideally six hundred on Unix systems. When running as a web application, ensure the cache file is writable by the web app user. In containerized environments, mount the cache file or directory as a volume to persist sessions across container restarts.

---

## 📦 Backup Process

### What Gets Backed Up

The backup system captures comprehensive security configuration data. For policies, it captures policy ID, name, description, category, scope, sequence number, stateful flag, and TCP strict flag. For each rule within policies, it captures rule ID, display name, source groups and destination groups paths, services list including ANY and service paths, action such as ALLOW, DROP, or REJECT, sequence number, disabled status, and source and destination exclusion flags.

For groups, it captures group ID, display name, description, expression for membership criteria, extended expression for complex criteria, and system owned flag to distinguish user versus system groups. For services, it captures service ID, display name, description, service entries defining protocol and port details, default service flag, and system owned flag.

Additionally, the backup includes environment metadata with name, IP, base URL, and display name. It includes detailed statistics on policy, rule, group, and service counts. And it includes analyzed resources showing unique groups and services referenced in rules.

### Backup File Format

Each backup is saved as a JSON file with the structure containing an environment object with name, IP, environment code, base URL, and display name. It contains a backup timestamp in ISO 8601 format. It contains a statistics object with total policies, rules, groups, services, and backup duration. It contains a policies array with each policy containing its rules array. It contains a groups object with all groups, user groups, and system groups arrays. It contains a services object with all services, user services, default services, and system services arrays. And it contains an analyzed resources object with groups analysis and services analysis which can be populated with usage data.

Example structure:
```json
{
  "environment": {
    "name": "NSX-T UK",
    "ip": "10.190.200.3",
    "environment_code": "UK"
  },
  "backup_timestamp": "2024-12-01T14:30:45.123456",
  "statistics": {
    "total_policies": 45,
    "total_rules": 237,
    "total_groups": 128,
    "total_services": 89
  },
  "policies": [...],
  "groups": {...},
  "services": {...}
}
```

### Backup Frequency

The backup system is designed to be called on-demand rather than on a schedule. Typical usage patterns include running backup before making any policy changes to have a restore point, running backup after group or service creation to refresh UI data, running backup daily for routine audit and compliance, and running backup via API call from web applications when users click a refresh button.

The parallel processing means a full backup of all four environments completes in under thirty seconds, making frequent backups practical without performance impact.

---

## ✨ Key Features

### Feature 1: Parallel Processing

The system achieves maximum speed through multi-level parallelism. At the orchestration level, all environments back up simultaneously using ThreadPoolExecutor. Within each environment, policies are processed in batches with twenty concurrent workers fetching rules. Groups and services are fetched in parallel using a two-worker pool. This reduces total backup time from approximately three to four minutes sequentially to approximately twenty-five to thirty seconds for all four environments.

### Feature 2: Rate Limit Handling

Production NSX environments, especially EU, frequently return HTTP four twenty nine rate limit errors. The system handles this gracefully with retry logic. When a four twenty nine response is received, the system waits two seconds on first retry, four seconds on second retry, six seconds on third retry, then gives up and logs the error. The exponential backoff prevents overwhelming the NSX API while giving transient rate limits time to clear. This was critical for reliable EU backups.

### Feature 3: Session Caching

Session caching provides significant performance and user experience benefits. It eliminates password prompts for repeated operations, reduces authentication overhead from five to ten seconds per environment to near zero, enables rapid successive operations without re-authentication, and shares sessions across different scripts and processes. The cache automatically expires after twenty-five minutes matching NSX session lifetime, ensuring security while maximizing usability.

### Feature 4: Data Validation

Before saving any backup, the system validates that the data is complete. It checks that groups count is greater than zero, and services count is greater than zero. If both are zero, it throws a fatal error with message stating backup would contain zero groups and zero services, aborting to prevent data loss, this is likely an NSX authentication or session issue. This prevents corrupt or incomplete backups from overwriting good data, especially important when backups are used by production web applications.

### Feature 5: High Latency Support

The IN environment has three times higher latency than other environments due to geographic distance. The system accommodates this with increased timeout of three hundred seconds or five minutes per environment compared to sixty seconds for other environments. Unbuffered stdout and stderr in workers for immediate log visibility. And connection pooling with twenty maximum connections to reduce connection overhead. This ensures reliable backups even from high-latency environments.

### Feature 6: Comprehensive Logging

Throughout the backup process, the system provides detailed logging for debugging and monitoring. Worker processes log authentication status, API response codes, data counts, retry attempts, and completion status. The orchestrator logs parallel execution progress, result collection, and final summary. Logs are prefixed with environment code for easy filtering, making it simple to diagnose issues with specific environments.

---

## 💻 Code Examples

### Example 1: Running a Complete Backup

```python
#!/usr/bin/env python3
"""Example: Run complete backup of all NSX environments"""

import sys
sys.path.append('/path/to/backup_system')

from create_backup import ParallelNSXBackup

def run_backup():
    """Run backup and handle results"""
    try:
        # Create backup manager
        backup = ParallelNSXBackup()
        
        # Run complete backup (this handles all environments in parallel)
        success = backup.run_complete_backup()
        
        if success:
            print("Backup completed successfully!")
            return True
        else:
            print("Backup completed with errors")
            return False
            
    except Exception as e:
        print(f"Backup failed: {e}")
        return False

if __name__ == "__main__":
    success = run_backup()
    sys.exit(0 if success else 1)
```

### Example 2: Loading Backup Data in Your Application

```python
#!/usr/bin/env python3
"""Example: Load and use backup data in your web application"""

import json
from pathlib import Path

def load_nsx_backups(backup_dir):
    """Load all NSX backup files"""
    backups = {}
    
    backup_path = Path(backup_dir)
    for backup_file in backup_path.glob("*_complete_backup.json"):
        # Extract environment code from filename
        env_code = backup_file.stem.split('_')[0].upper()
        
        # Load backup data
        with open(backup_file, 'r', encoding='utf-8') as f:
            backups[env_code] = json.load(f)
    
    return backups

def get_policies_for_environment(backups, env_code):
    """Get all policies for a specific environment"""
    if env_code not in backups:
        return []
    
    return backups[env_code].get('policies', [])

def get_groups_for_environment(backups, env_code):
    """Get all user-created groups for a specific environment"""
    if env_code not in backups:
        return []
    
    groups_data = backups[env_code].get('groups', {})
    return groups_data.get('user_groups', [])

# Usage example
if __name__ == "__main__":
    # Load all backups
    backups = load_nsx_backups('/path/to/backup_system/nsx_backups')
    
    # Get UK policies
    uk_policies = get_policies_for_environment(backups, 'UK')
    print(f"Found {len(uk_policies)} policies in UK environment")
    
    # Get US groups
    us_groups = get_groups_for_environment(backups, 'US')
    print(f"Found {len(us_groups)} user groups in US environment")
```

### Example 3: Integrating with Flask Web Application

```python
#!/usr/bin/env python3
"""Example: Flask API endpoint to trigger backup and return results"""

from flask import Flask, jsonify
import subprocess
import json
from pathlib import Path

app = Flask(__name__)

@app.route('/api/refresh_nsx_backup', methods=['POST'])
def refresh_backup():
    """
    API endpoint to trigger NSX backup refresh
    Called when user clicks "Refresh" button in UI
    """
    try:
        # Run backup script
        backup_script = Path(__file__).parent / 'backup_system' / 'create_backup.py'
        result = subprocess.run(
            ['python3', str(backup_script)],
            capture_output=True,
            text=True,
            timeout=600  # 10 minute timeout
        )
        
        if result.returncode == 0:
            # Load the updated backups
            backup_dir = Path(__file__).parent / 'backup_system' / 'nsx_backups'
            backups_available = list(backup_dir.glob("*_complete_backup.json"))
            
            return jsonify({
                'success': True,
                'message': f'Backup completed successfully',
                'environments_backed_up': len(backups_available),
                'timestamp': datetime.now().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Backup script failed',
                'stderr': result.stderr
            }), 500
            
    except subprocess.TimeoutExpired:
        return jsonify({
            'success': False,
            'error': 'Backup timed out after 10 minutes'
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/get_policies/<env_code>', methods=['GET'])
def get_policies(env_code):
    """
    API endpoint to get policies for a specific environment
    """
    try:
        backup_file = Path(__file__).parent / 'backup_system' / 'nsx_backups' / f'{env_code}_complete_backup.json'
        
        if not backup_file.exists():
            return jsonify({
                'success': False,
                'error': f'No backup found for environment {env_code}'
            }), 404
        
        with open(backup_file, 'r', encoding='utf-8') as f:
            backup_data = json.load(f)
        
        policies = backup_data.get('policies', [])
        
        return jsonify({
            'success': True,
            'environment': env_code,
            'policy_count': len(policies),
            'policies': policies
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, port=8000)
```

### Example 4: Checking Authentication Status

```python
#!/usr/bin/env python3
"""Example: Check if valid cached sessions exist"""

import json
from datetime import datetime
from pathlib import Path

def check_cached_sessions(cache_file_path):
    """Check which NSX environments have valid cached sessions"""
    try:
        with open(cache_file_path, 'r') as f:
            cache_data = json.load(f)
        
        now = datetime.now()
        valid_sessions = []
        expired_sessions = []
        
        for env_key, session_data in cache_data.items():
            expiry = datetime.fromisoformat(session_data['expiry'])
            
            if expiry > now:
                valid_sessions.append({
                    'environment': session_data['nsx_env'],
                    'ip': session_data['nsx_ip'],
                    'username': session_data['username'],
                    'expires_in_minutes': (expiry - now).total_seconds() / 60
                })
            else:
                expired_sessions.append({
                    'environment': session_data['nsx_env'],
                    'ip': session_data['nsx_ip']
                })
        
        return {
            'valid': valid_sessions,
            'expired': expired_sessions
        }
        
    except FileNotFoundError:
        return {
            'valid': [],
            'expired': [],
            'error': 'Cache file not found - no sessions cached yet'
        }
    except Exception as e:
        return {
            'valid': [],
            'expired': [],
            'error': str(e)
        }

# Usage
if __name__ == "__main__":
    cache_file = Path(__file__).parent / 'data' / 'nsx_session_cache.json'
    status = check_cached_sessions(cache_file)
    
    print(f"Valid sessions: {len(status['valid'])}")
    for session in status['valid']:
        print(f"  - {session['environment']} ({session['username']}) - expires in {session['expires_in_minutes']:.1f} minutes")
    
    print(f"\nExpired sessions: {len(status['expired'])}")
    for session in status['expired']:
        print(f"  - {session['environment']}")
```

---

## 🔧 Troubleshooting

### Issue 1: Authentication Failures

**Symptom**: Workers fail with authentication errors or session is None messages.

**Possible Causes**: Cached session expired or corrupted. Incorrect username or password. NSX manager not reachable on configured IP. Firewall blocking connection on port 443.

**Solutions**: Delete the session cache file and retry to force fresh authentication. Verify NSX IP addresses in nsx environments dot json are correct. Test connectivity using curl or browser to https colon slash slash NSX IP. Check that username has appropriate NSX permissions for read access. Set NSX USERNAME environment variable if not using interactive prompt.

### Issue 2: Empty or Partial Backups

**Symptom**: Backup files created but contain zero groups or services, or backup fails with fatal error about empty data.

**Possible Causes**: API session lost mid-backup. NSX API rate limiting too severe. Network interruption during backup. Insufficient permissions to read resources.

**Solutions**: Check worker logs for API response codes especially four twenty nine rate limit errors. Increase retry delays in the rate limit handling code. Verify user account has read permissions for groups and services APIs. Run backup during off-peak hours to avoid rate limiting. Consider running environments sequentially instead of parallel if rate limiting persists.

### Issue 3: Slow Backup Performance

**Symptom**: Backups take several minutes instead of under a minute.

**Possible Causes**: High network latency to NSX managers. NSX API responding slowly under heavy load. Insufficient ThreadPoolExecutor workers. Sequential processing instead of parallel.

**Solutions**: Check network latency using ping to NSX IP addresses. Verify parallel processing is enabled in create backup dot py with ThreadPoolExecutor. Increase max workers from twenty to thirty in worker scripts if latency is high. Consider increasing timeout values for high-latency environments. Run backups during off-peak hours when NSX load is lower.

### Issue 4: Rate Limiting Errors

**Symptom**: Workers log HTTP four twenty nine errors repeatedly, EU environment consistently fails.

**Possible Causes**: NSX API rate limits exceeded. Too many concurrent requests. Insufficient backoff delay between retries.

**Solutions**: The system already implements retry with exponential backoff, but you can increase delays. Change retry delays from two, four, six seconds to five, ten, fifteen seconds. Reduce max workers from twenty to ten in worker scripts. Add a longer delay before fetching groups and services, currently three seconds, increase to five or ten seconds. Consider running EU backup separately with lower concurrency. Contact NSX administrator to check if rate limits can be increased.

### Issue 5: Container Deployment Issues

**Symptom**: Backups work locally but fail in Docker containers.

**Possible Causes**: Session cache file not persisted across container restarts. Incorrect file paths for containerized environment. Network routing issues from container to NSX. Volume mount not configured correctly.

**Solutions**: Mount session cache directory as Docker volume with dash v option. Use environment variables for paths instead of hardcoded paths. Verify container can reach NSX IPs using docker exec and curl. Check container logs for authentication and network errors. Ensure container has write permissions to backup directory. Mount backup directory as volume to persist backups outside container.

### Issue 6: Import Errors

**Symptom**: Workers fail with ModuleNotFoundError for modules like NSX login or create service API.

**Possible Causes**: Python path not configured correctly. Modules directory not in expected location. sys dot path not including parent directories.

**Solutions**: Verify modules directory contains NSX login dot py and create service API dot py. Check sys dot path dot append statements in worker scripts point to correct directories. Use absolute paths in sys dot path dot append instead of relative paths. Ensure __init__ dot py exists in modules directory for Python package recognition. Print sys dot path in worker scripts to debug path issues.

---

## 📊 Performance Metrics

Based on production usage with four NSX environments UK, US, EU, IN:

**Sequential Backup** (old approach):
- UK environment: 45 seconds
- US environment: 50 seconds  
- EU environment: 90 seconds (high latency)
- IN environment: 60 seconds
- Total: 245 seconds or approximately 4 minutes

**Parallel Backup** (current approach):
- All environments simultaneously: 25 to 30 seconds
- Speedup: approximately 8x faster
- Longest pole: EU environment at approximately 25 seconds due to rate limiting

**Per-Environment Breakdown**:
- Authentication: 2 to 5 seconds (or near zero with cached session)
- Policy fetch: 2 to 3 seconds
- Rules fetch (20 concurrent workers): 8 to 12 seconds
- Groups and services fetch (parallel): 5 to 8 seconds
- JSON serialization: less than 1 second

---

## 🎯 Best Practices

### For Development
1. Test authentication separately before running full backups
2. Start with one environment then scale to parallel
3. Monitor NSX API logs for rate limiting patterns
4. Use extensive logging during development
5. Validate backup data structure before using in applications

### For Production
1. Mount session cache as persistent volume in containers
2. Mount backup directory as volume to preserve data
3. Set up monitoring for backup success rates
4. Implement alerting for backup failures
5. Schedule daily backups during off-peak hours
6. Keep backup retention policy, for example last 7 days
7. Test restore procedures periodically

### For Integration
1. Use subprocess to call backup script from web applications
2. Implement proper timeout handling, recommend 10 minutes
3. Provide user feedback during backup progress
4. Cache backup data in memory to avoid repeated file reads
5. Implement backup versioning if needed
6. Use backup timestamp to detect stale data
7. Handle missing backup files gracefully

---

## 📚 Additional Resources

### NSX-T API Documentation
- Session Management: NSX-T API Reference slash api slash session
- Security Policies: NSX-T API Reference slash policy slash api slash v1 slash infra slash domains slash domain-id slash security-policies
- Groups: NSX-T API Reference slash policy slash api slash v1 slash infra slash domains slash domain-id slash groups
- Services: NSX-T API Reference slash policy slash api slash v1 slash infra slash services

### Python Libraries Used
- **requests**: HTTP library for API calls - https://requests.readthedocs.io
- **urllib3**: Low-level HTTP handling - https://urllib3.readthedocs.io
- **concurrent.futures**: Parallel execution framework - https://docs.python.org/3/library/concurrent.futures.html

### Related Documentation
- Commit 9e3689ef: Automatic backup refresh after group creation
- Commit df7e0520: UI refresh via SocketIO events
- Commit f51ca83a: High-latency environment timeout fixes
- Commit 1f1fbda4: Rate limiting retry mechanism
- Commit a7f8c20a: Multi-environment filter fix

---

## 🤝 Support and Contact

For questions about this backup system implementation:
- Contact: Sagiv (original implementer)
- Project: NSX Policy Replication Web App
- Repository: API_NSX/create_DC_rules

**Note for Tal**: This package contains everything you need to implement NSX backup fetching in your own web application. The code is production-tested and handles the edge cases we encountered over months of development. Feel free to adapt it to your specific needs!

---

*Document Version: 1.0*  
*Last Updated: February 2026*  
*Generated for: Tal's NSX Web Application Project*
